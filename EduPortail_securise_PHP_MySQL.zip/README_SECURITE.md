# EduPortail — passage à un vrai backend PHP + MySQL

Cette version conserve le frontend mais déplace l'authentification côté serveur.

## 1. Pré-requis
- PHP 8.1+ recommandé
- MySQL/MariaDB
- HTTPS en production
- PDO MySQL activé

## 2. Base de données
Importez `database.sql` dans MySQL.

Puis créez `backend/config.local.php` à partir de `backend/config.local.php.example` et renseignez les identifiants MySQL.

Adaptez `backend/config.php` pour charger votre configuration locale, ou remplacez les constantes par vos valeurs sur un serveur protégé.

## 3. Créer le premier compte
Depuis le terminal, dans le dossier du projet :

    php create_admin.php

Choisissez un mot de passe fort d'au moins 12 caractères.

Le mot de passe est transformé avec `password_hash()` et n'est jamais stocké en clair.

Supprimez/protégez `create_admin.php` après création du premier compte.

## 4. Lancer en local
Depuis le dossier du projet :

    php -S localhost:8000

Puis ouvrez :

    http://localhost:8000/

## 5. Ce qui est maintenant sécurisé
- Le mot de passe n'est plus dans JavaScript.
- Le rôle réel est lu depuis MySQL.
- Les pages de rôle sont protégées côté serveur.
- Les sessions sont côté serveur, avec cookie HttpOnly/SameSite.
- `session_regenerate_id()` est utilisé après connexion.
- Les requêtes SQL utilisent PDO + requêtes préparées.
- Aucun élève n'est créé automatiquement.

## 6. À compléter avant production
- HTTPS obligatoire.
- Protection CSRF pour les opérations POST/PUT/DELETE métier.
- Limitation anti-bruteforce / rate limiting et éventuellement verrouillage progressif.
- Journalisation/audit des actions sensibles.
- Contrôles d'autorisation fins : un professeur ne doit voir que ses classes, un parent uniquement ses enfants, etc.
- Validation stricte des entrées.
- Sauvegardes chiffrées et politique de restauration.
- Secrets DB hors du dossier public et idéalement via variables d'environnement.
- En-têtes de sécurité HTTP (CSP, HSTS, X-Content-Type-Options, etc.).
- Gestion sécurisée des fichiers si vous ajoutez des documents.
- Réinitialisation de mot de passe avec jetons temporaires à usage unique.
