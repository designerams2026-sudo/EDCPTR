# EduPortail — version sécurisée de démarrage

Cette archive est une base de migration du frontend vers PHP + MySQL.
Lisez `README_SECURITE.md` avant installation.

Important : aucun compte et aucun élève n'est créé automatiquement.
