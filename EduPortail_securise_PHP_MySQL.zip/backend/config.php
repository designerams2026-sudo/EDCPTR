<?php
declare(strict_types=1);

/*
 * Copiez ce fichier en config.local.php et renseignez les accès MySQL.
 * config.local.php ne doit pas être commité ni exposé publiquement.
 */
const DB_HOST = '127.0.0.1';
const DB_NAME = 'eduportail';
const DB_USER = 'eduportail_user';
const DB_PASS = 'CHANGE_ME';

const SESSION_NAME = 'eduportail_session';
