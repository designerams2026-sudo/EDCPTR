<?php
declare(strict_types=1);

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../auth.php';

$user = require_login();

/*
 * Exemple minimal : les données sont lues depuis MySQL.
 * Ajoutez ensuite des règles d'autorisation adaptées à votre établissement.
 */
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_response(['error' => 'Méthode non autorisée'], 405);
}

$stmt = db()->query('SELECT id, first_name, last_name, class_name FROM students ORDER BY last_name, first_name');
json_response(['students' => $stmt->fetchAll()]);
