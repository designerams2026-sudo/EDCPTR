<?php
declare(strict_types=1);
require_once __DIR__ . '/../auth.php';

$user = current_user();
if (!$user) json_response(['authenticated' => false]);

json_response([
    'authenticated' => true,
    'id' => $user['id'],
    'username' => $user['username'],
    'role' => $user['role'],
    'connected_at' => $user['connected_at'],
]);
