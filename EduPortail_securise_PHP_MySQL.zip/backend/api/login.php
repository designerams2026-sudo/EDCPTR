<?php
declare(strict_types=1);

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../auth.php';

start_secure_session();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['error' => 'Méthode non autorisée'], 405);
}

$input = json_decode(file_get_contents('php://input'), true) ?: [];
$username = trim((string)($input['username'] ?? ''));
$password = (string)($input['password'] ?? '');
$requestedRole = (string)($input['role'] ?? '');

if ($username === '' || $password === '') {
    json_response(['error' => 'Identifiant et mot de passe requis.'], 400);
}

$stmt = db()->prepare('SELECT id, username, password_hash, role, active FROM users WHERE username = ? LIMIT 1');
$stmt->execute([$username]);
$user = $stmt->fetch();

if (!$user || !(bool)$user['active'] || !password_verify($password, $user['password_hash'])) {
    usleep(250000);
    json_response(['error' => 'Identifiant ou mot de passe incorrect.'], 401);
}

/* Le rôle choisi dans l'interface n'accorde aucun privilège.
   Le rôle réel vient uniquement de la base de données. */
if ($requestedRole !== '' && $requestedRole !== $user['role']) {
    json_response(['error' => 'Ce compte ne correspond pas à cet espace.'], 403);
}

session_regenerate_id(true);
$_SESSION['user'] = [
    'id' => (int)$user['id'],
    'username' => $user['username'],
    'role' => $user['role'],
    'connected_at' => date(DATE_ATOM),
];

json_response(['ok' => true, 'redirect_role' => $user['role']]);
