<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

function start_secure_session(): void {
    if (session_status() === PHP_SESSION_ACTIVE) return;

    session_name(SESSION_NAME);
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

function current_user(): ?array {
    start_secure_session();
    return $_SESSION['user'] ?? null;
}

function require_login(): array {
    $user = current_user();
    if (!$user) {
        header('Location: /index.html', true, 302);
        exit;
    }
    return $user;
}

function require_role(string $role): array {
    $user = require_login();
    if (($user['role'] ?? '') !== $role) {
        http_response_code(403);
        echo '<!doctype html><meta charset="utf-8"><title>Accès refusé</title>';
        echo '<p>Accès refusé.</p>';
        exit;
    }
    return $user;
}

function json_response(array $data, int $status=200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}
